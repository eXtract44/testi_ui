/*
 * time.h
 *
 *  Created on: Sep 25, 2021
 *      Author: sasho
 */

#ifndef INC_TIME_H_
#define INC_TIME_H_

void get_time();

#endif /* INC_TIME_H_ */
