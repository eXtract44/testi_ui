/*
 * prossing.h
 *
 *  Created on: Sep 21, 2021
 *      Author: sasho
 */

#ifndef INC_PROCESSING_H_
#define INC_PROCESSING_H_

void start_buzzer(uint8_t status);

void processing();

#endif /* INC_PROCESSING_H_ */
