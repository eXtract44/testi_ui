#ifndef INC_MENU_H_
#define INC_MENU_H_



#define DISPLAY_WIDTH 320  //px
#define DISPLAY_HEIGHT 240  //px


#define MAX_FRAME_SIZE_BTN 10  //px
#define MAX_WIDTH_SIZE_BTN DISPLAY_WIDTH / 2  //px
#define MAX_HIGH_SIZE_BTN DISPLAY_HEIGHT / 2  //px




enum currentMenu{
MAIN_MENU,
SENSOR_MENU,
ACTOR_MENU,
INFO_MENU,
SETTING_MENU
};

#endif /* INC_MENU_H_ */
